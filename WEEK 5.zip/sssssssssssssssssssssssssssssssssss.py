Python 3.5.2 (v3.5.2:4def2a2901a5, Jun 25 2016, 22:01:18) [MSC v.1900 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> 
================= RESTART: C:/Users/21368236/Desktop/DB7.py =================
Traceback (most recent call last):
  File "C:/Users/21368236/Desktop/DB7.py", line 3, in <module>
    print (s/7)
TypeError: unsupported operand type(s) for /: 'str' and 'int'
>>> 
=============== RESTART: C:/Users/21368236/Desktop/RICHTER.py ===============
Traceback (most recent call last):
  File "C:/Users/21368236/Desktop/RICHTER.py", line 3, in <module>
    richter = int (richter)
ValueError: invalid literal for int() with base 10: 'Richter scale:'
>>> 
=============== RESTART: C:/Users/21368236/Desktop/RICHTER.py ===============
Traceback (most recent call last):
  File "C:/Users/21368236/Desktop/RICHTER.py", line 3, in <module>
    richter = int (richter)
ValueError: invalid literal for int() with base 10: 'Richter scale'
>>> 
=============== RESTART: C:/Users/21368236/Desktop/RICHTER.py ===============
Traceback (most recent call last):
  File "C:/Users/21368236/Desktop/RICHTER.py", line 2, in <module>
    richter = int (richter)
ValueError: invalid literal for int() with base 10: 'Richter scale'
>>> 
=============== RESTART: C:/Users/21368236/Desktop/RICHTER.py ===============
Richter scale5
Damage to poorly constructed buildings
>>> 7
7
>>> 
=============== RESTART: C:/Users/21368236/Desktop/RICHTER.py ===============
Richter scale7
Many buildings destroyed
Richter scale5
>>> 
