richter = input("Richter scale")
richter = int (richter)
if (richter >= 8):
    print ("Most structures fall")
elif (richter >= 7):
    print ("Many buildings destroyed")
elif (richter >= 6):
    print ("Many buildings considerably damaged, some collapse")
elif (richter >= 4.5):
    print ("Damage to poorly constructed buildings")
else:
    print ("Destruction of buildings most unlikely")
richter = input("Richter scale")
