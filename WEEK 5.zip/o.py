username= "username"
residence= "residence"
