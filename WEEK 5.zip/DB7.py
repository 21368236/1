s= ("7")
int (s)
print (s/7)
