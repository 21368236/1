/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package a070822;

/**
 *
 * @author 21368236
 */
public class A070822 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println ("ǂomone !kwa Java\n ǂomone !kwa tb'irefeng m'buum\n Bukoro se ʘeyoǀek") ;
        System.out.println ("EBH N'N 0K30 SE []\n favourite TV PROGRAM IS VARIOUS FACTUAL DOCUMENTARIES \n I WOKE UP AT 05:56 \n target grade is ABOVE PASS IN 2022 , THE HIGHEST IN 2064") ;
       
        
    }
    
}
